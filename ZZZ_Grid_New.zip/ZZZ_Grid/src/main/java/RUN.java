import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RUN {

	static WebDriver driver=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.autohero.com/de/search/?sort=DISTANCE_DESC");
		
		driver.findElement(By.xpath("//*[@class='Select hidden-xs hidden-sm has-value Select--single']//span[@class='Select-arrow-zone']")).click();
		
		WebElement element= driver.findElement(By.xpath(".//*[@id='react-select-8--option-4']/div/span[text()='Marke - A bis Z']"));
		element.click();
		
		System.out.println("sss");
	//	driver.close();
	}

}
